package com.example.bod.kotlincoroutines.activity.ktlist

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.example.bod.kotlincoroutines.R
import com.example.bod.kotlincoroutines.activity.AsyncInflateActivity
import com.example.bod.kotlincoroutines.activity.GlideActivity
import kotlinx.android.synthetic.main.ktmain_layout.*
import org.koin.android.ext.android.inject
import org.koin.android.viewmodel.ext.android.viewModel
import timber.log.Timber

/**
 *
 * @ClassName: KtMainActivity
 * @Description:
 * @CreateDate: 2019/9/14
 */
class KtMainActivity : AppCompatActivity() {

    private val ktViewModel: KtViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ktmain_layout)
        ktViewModel.userLiveData.observe(this, Observer { banner ->
            Timber.d("Banner $banner \n}")
            Timber.d("class ${banner.javaClass}")
        })

        textView.setOnClickListener {
            ktViewModel.getBanner()
            it.context.startActivity<GlideActivity>()
        }
    }

    private inline fun <reified T> Context.startActivity() {
        val intent = Intent(this, T::class.java)
        startActivity(intent)
    }

    //具体时期可以进行获取
//    inline fun <reified T> jum(){}  调用方 jump<>() <>中的数据需要自己去指定

}