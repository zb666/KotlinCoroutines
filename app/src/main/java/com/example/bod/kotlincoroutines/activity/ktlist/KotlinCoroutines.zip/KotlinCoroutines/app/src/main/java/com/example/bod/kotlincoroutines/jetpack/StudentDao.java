package com.example.bod.kotlincoroutines.jetpack;

/**
 * @ClassName: StudentDao
 * @Description:
 * @CreateDate: 2019/8/1
 */

public interface StudentDao {
}
