package com.example.bod.kotlincoroutines.glidefolder;

/**
 * @ClassName: IRequestListener
 * @Description:
 * @CreateDate: 2019/9/5
 */
public interface IRequestListener {
}
