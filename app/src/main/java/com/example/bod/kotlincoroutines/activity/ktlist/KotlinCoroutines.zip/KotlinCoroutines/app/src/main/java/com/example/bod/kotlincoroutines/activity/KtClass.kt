package com.example.bod.kotlincoroutines.activity

import log
import java.util.*

/**
 *
 * @ClassName: KtClass
 * @Description:
 * @CreateDate: 2019/9/15
 */

fun main() {
    val listStr = arrayListOf("1")
    val listInteger = listOf(1)


}

inline fun <reified T> getType(): Class<T> {
    return T::class.java
}
