package com.example.bod.kotlincoroutines.coroutine
import com.example.bod.kotlincoroutines.utils.log
import kotlinx.coroutines.coroutineScope

fun main() = {
   log("15K 钛合金 小胖子王")


}
