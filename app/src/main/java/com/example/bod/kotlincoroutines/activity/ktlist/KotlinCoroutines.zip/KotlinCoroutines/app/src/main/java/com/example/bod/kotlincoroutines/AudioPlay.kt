package com.example.bod.kotlincoroutines

/**
 *
 * @ClassName: AudioPlay
 * @Description:
 * @CreateDate: 2019/9/11
 */
class AudioPlay(private val name:String = "MyName") {

    fun getName():String{
        return name
    }

}