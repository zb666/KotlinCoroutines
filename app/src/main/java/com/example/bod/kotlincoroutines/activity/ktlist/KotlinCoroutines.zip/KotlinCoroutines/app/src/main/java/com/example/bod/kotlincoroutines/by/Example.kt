package com.example.bod.kotlincoroutines.by

/**
 *
 * @ClassName: Example
 * @Description:
 * @CreateDate: 2019/7/31
 */
class Example {
    val str:String by Delegate()
}