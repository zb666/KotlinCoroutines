package com.example.bod.kotlincoroutines.activity.ktlist

/**
 *
 * @ClassName: User
 * @Description:
 * @CreateDate: 2019/9/14
 */
data class User(val name:String,val age:Int)