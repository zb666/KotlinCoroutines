package com.example.bod.kotlincoroutines;

/**
 * @ClassName: UPush
 * @Description:
 * @CreateDate: 2019/9/3
 */
public enum UPush {

    A("枚举的值"),
    B("B"),
    C("C");

    public String string;

    UPush(String str) {
        this.string = str;
    }
}
