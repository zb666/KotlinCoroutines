package com.example.bod.kotlincoroutines.activity.ktlist

data class Banner(
    val data: List<Data>,
    val errorCode: Int,
    val errorMsg: String
)