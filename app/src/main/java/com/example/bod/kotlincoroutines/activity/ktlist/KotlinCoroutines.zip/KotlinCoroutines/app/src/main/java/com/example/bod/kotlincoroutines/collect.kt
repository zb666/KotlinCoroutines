package com.example.bod.kotlincoroutines

/**
 *
 * @ClassName: collect
 * @Description:
 * @CreateDate: 2019/8/28
 */

object  AAA

public fun <T> emptyList():AAA = AAA