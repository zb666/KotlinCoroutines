package com.example.bod.kotlincoroutines.activity;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: TypeClass
 * @Description:
 * @CreateDate: 2019/9/15
 */
public class TypeClass {

    public static void main(String args[]){
        List<String> list = new ArrayList<>();
        List<Integer> integerList = new ArrayList<>();

        System.out.println(list.getClass()+" "+integerList.getClass()+" "+(list.getClass()==integerList.getClass()));


    }
    //public <T extends Parcelable> T getParcelable(@Nullable String key) {




}
