package com.example.bod.kotlincoroutines.activity.ktlist

/**
 *
 * @ClassName: IUserRepository
 * @Description:
 * @CreateDate: 2019/9/14
 */
interface IUserRepository {

    fun getUser():User

}