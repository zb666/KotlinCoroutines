package com.example.bod.kotlincoroutines

import org.jetbrains.annotations.TestOnly

/**
 *
 * @ClassName: StatusTest
 * @Description:
 * @CreateDate: 2019/8/13
 */
class StatusTest {

    var status = 0x000001

    @TestOnly
    fun main(){

    }

}