package com.example.bod.kotlincoroutines

/**
 *
 * @ClassName: Body
 * @Description:
 * @CreateDate: 2019/8/24
 */
class Body constructor(val  name:String,val age:Int) {

}