package com.example.bod.kotlincoroutines

import android.os.SystemClock
import com.example.bod.kotlincoroutines.utils.printLog
import kotlinx.coroutines.*

fun main() {

}
