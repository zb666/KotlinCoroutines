package com.example.bod.kotlincoroutines

class LogUtils {

    companion object {
        const val name:String = "object single"

        fun addName() = "伴深对象中的方法"
    }

}