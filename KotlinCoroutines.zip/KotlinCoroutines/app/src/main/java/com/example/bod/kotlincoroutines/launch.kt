package com.example.bod.kotlincoroutines

import android.os.SystemClock
import com.example.bod.kotlincoroutines.utils.printLog
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

 fun main() {
     
}