package com.example.bod.kotlincoroutines.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.bod.kotlincoroutines.R

/**
 *
 * @ClassName: MotionActivity
 * @Description:
 * @CreateDate: 2019/8/1
 */
class MotionActivity:AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_scene_start)
    }

}