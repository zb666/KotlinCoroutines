package com.example.bod.kotlincoroutines.by

/**
 *
 * @ClassName: Derived
 * @Description:
 * @CreateDate: 2019/7/31
 */
class Derived(b:BaseImpl):IBase by b


