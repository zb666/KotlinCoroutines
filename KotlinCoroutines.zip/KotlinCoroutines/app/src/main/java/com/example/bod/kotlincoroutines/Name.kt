package com.example.bod.kotlincoroutines

/**
 *
 * @ClassName: Name
 * @Description:
 * @CreateDate: 2019/7/31
 */
class Name  {
    var name:String = ""

    companion object {
        fun getName():String = "name"
    }
}