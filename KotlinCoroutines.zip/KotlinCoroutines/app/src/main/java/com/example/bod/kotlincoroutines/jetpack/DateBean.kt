package com.example.bod.kotlincoroutines.jetpack

/**
 *
 * @ClassName: DateBean
 * @Description:
 * @CreateDate: 2019/8/1
 */
data class DateBean(var id:Long,var name:String)