package com.example.bod.kotlincoroutines.by

/**
 *
 * @ClassName: IBase
 * @Description:
 * @CreateDate: 2019/7/31
 */
interface IBase {
    fun print()
}